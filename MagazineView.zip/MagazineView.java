//MagazineView.java
//Author: Tommy Li
//Version: 1.0
//12/17/2022

//Algorithm:
//1.Create layout using Gui features like textfields, buttons, labels, and input 
//2.input text into "insert magazine" and it gets stored into a var when "enter" key is pressed
//3.press listMagazines and it shows what is stored
//4.input text into "delete magazine" and it deletes the text from the variable
//5.press "delete all" will delete everything stored inside the variable

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class MagazineView extends Application{ 
  // sets the scene for the program
  public void start(Stage stage)
    {
        Scene scene = new Scene(new MagazineViewPane(), 390, 455);
        stage.setTitle("Magazine List");
        stage.setScene(scene);
        stage.show();
       
    }
   public static void main(String[] args)
    {
	   launch(args);
    }
}