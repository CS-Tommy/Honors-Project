//  Magazine.java       
//  Author: Tommy Li
//  this file presents one magazine object

public class Magazine implements Comparable<Magazine>
{
    private String magTitle;

    public Magazine(String name) 	// creates the magazine with a title
    {    
        magTitle = name;
    }

    public String toString() // returns the Magazine title in a string
    {
        return magTitle;
    }

public int compareTo(Magazine other) { //overrides compareTo method

    int result;
    System.out.println();

    if (magTitle.equals(other.toString()))
      result = magTitle.compareTo(other.toString());
    else
      result = magTitle.compareTo(other.toString());

    return result;

  }
}

