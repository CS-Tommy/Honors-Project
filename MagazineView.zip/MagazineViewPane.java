//MagazineViewPane.java       
//Author: Tommy Li
//Creates the GUI

import javafx.event.ActionEvent;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.TextArea;
import javafx.scene.control.ButtonBase;
import javafx.scene.control.Button;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.event.EventHandler;
import javafx.scene.canvas.*;
import javafx.scene.Group;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.Scene; 
import javafx.stage.Stage; 
import javafx.application.Application;
import javafx.geometry.HPos;
import javafx.geometry.Pos;

public class MagazineViewPane extends GridPane
  
{
  
  private TextField add;
  private TextField delete;
  private TextArea list;
  private Button deleteButton;
  private Button listButton;
  private MagazineList List2 = new MagazineList();
 
  public MagazineViewPane()
  {

  	Label addLabel = new Label("Magazine Name:");
  	Label deleteLabel = new Label("Delete Magazine:");
  	delete = new TextField();
  	add = new TextField();
  	list = new TextArea();    
  	listButton = new Button("List Magazines");
  	deleteButton = new Button("Delete Magazines");

    
     GridPane.setHalignment(addLabel, HPos.CENTER);
     GridPane.setHalignment(listButton, HPos.LEFT);
     GridPane.setHalignment(add, HPos.CENTER);
     GridPane.setHalignment(list, HPos.CENTER);
     GridPane.setHalignment(delete, HPos.CENTER);
     GridPane.setHalignment(deleteButton, HPos.RIGHT);
     GridPane.setHalignment(deleteLabel, HPos.CENTER);
     list.setPrefHeight(400);
     list.setPrefWidth(270);
     add(addLabel,2,1);
     add(listButton,3,2);
     add(add,2,2);
     add(list,2,3);
     add(delete,2,5);
     add(deleteButton,3,5);
     add(deleteLabel,2,4); 
     add.setOnAction(this:: addText);
     delete.setOnAction(this:: deleteText);
     deleteButton.setOnAction(this:: deleteAll);
     listButton.setOnAction(this:: show);

  }
  
  public void addText(ActionEvent event) //action to add typed magazines
    {

        Magazine temp = new Magazine(add.getText());
        List2.insert(temp);

    }

  public void deleteText(ActionEvent event) //action to delete typed magazines
    {

       Magazine temp = new Magazine(delete.getText());
       List2.delete(temp);

    }

  public void deleteAll(ActionEvent event) //action to delete all magazines
	{
  		List2.deleteAll();
  		list.setText(" ");
	}

  public void show(ActionEvent event) //action to show magazines
	{
  		list.setText(List2.toString());
	}
} 