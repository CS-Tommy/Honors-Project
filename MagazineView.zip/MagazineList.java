//  MagazineList.java     
//  Author: Tommy Li
//  This class represents multiple magazines

public class MagazineList 
{

    private MagazineNode list;

    public MagazineList() //creates an empty list of magazines with null
    {
        list = null;
    }

    public void add(Magazine mag) //creates new magazineNode and puts it towards the end of the list
    {

        MagazineNode node = new MagazineNode(mag);
        MagazineNode current;

        if (list == null){

            list = node;

		}else{

            current = list;

            while (current.next != null)
			{
				current = current.next;
			}

            current.next = node;
        }
    }
 
     public void insert(Magazine mag) //creates new magazineNode and puts it towards the front of the list
	{ 

      MagazineNode node = new MagazineNode(mag);

       if (list == null){

            list = node;

       }else{

        node.next = list;

        list = node;

     }
   }

    public void deleteAll() //deletes everything in Magazine
    {

      if(list !=null){

         list = null;
      }
     }

	public void delete(Magazine mag) //deletes input from Magazine
	{ 
  
    		MagazineNode node = new MagazineNode(mag);
      	MagazineNode prev = null;
    		MagazineNode current = list;

    while (current != null) 
	{
      if (current.magazine.compareTo(node.magazine)==0) 
		{   
          if(current == list)
			{

              		list = list.next;
              		current = list;

            	}else{

           		 prev.next = current.next;
            		 current = current.next;

          	}
      	}
		else{

          prev = current;
          current = current.next;

      }
   }
}

    public String toString() //returns list of magazines in a string
    {

        String result = "";

        MagazineNode current = list;

        while (current != null)
        {

            result += current.magazine + "\n";
            current = current.next;

        }

        return result;
    }

   
    //  An inside class that represents a node in the list of magazines.
    //  public vars are used by the magazineList class. 

    private class MagazineNode
    {

        public Magazine magazine;
        public MagazineNode next;

        public MagazineNode(Magazine mag) //creates the node
        {
            magazine = mag;
            next = null;
        }
    }
}

